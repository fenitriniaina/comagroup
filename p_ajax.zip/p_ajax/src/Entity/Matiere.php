<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;
use App\Repository\MatiereRepository;
use Doctrine\Common\Collections\Collection;
use Doctrine\Common\Collections\ArrayCollection;

/**
 * @ORM\Entity(repositoryClass=MatiereRepository::class)
 */
class Matiere
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $nom;

    /**
     * @ORM\Column(type="integer")
     */
    private $coef;

    /**
     * @ORM\ManyToMany(targetEntity=Professeur::class, mappedBy="matiere")
     */
    private $prof;

    public function __construct()
    {
        $this->prof = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function setId(int $val): self
    {
        $this->id = $val;

        return $this;
    }

    public function getNom(): ?string
    {
        return $this->nom;
    }

    public function setNom(string $nom): self
    {
        $this->nom = $nom;

        return $this;
    }

    public function getCoef(): ?int
    {
        return $this->coef;
    }

    public function setCoef(int $coef): self
    {
        $this->coef = $coef;

        return $this;
    }

    /**
     * @return Collection|Professeur[]
     */
    public function getProf(): Collection
    {
        return $this->prof;
    }

    public function addProf(Professeur $prof): self
    {
        if (!$this->prof->contains($prof)) {
            $this->prof[] = $prof;
            $prof->addMatiere($this);
        }

        return $this;
    }

    public function removeProf(Professeur $prof): self
    {
        if ($this->prof->contains($prof)) {
            $this->prof->removeElement($prof);
            $prof->removeMatiere($this);
        }

        return $this;
    }
}
