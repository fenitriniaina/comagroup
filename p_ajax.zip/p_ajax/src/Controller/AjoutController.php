<?php

namespace App\Controller;

use App\Entity\Matiere;
use App\Entity\Professeur;
use App\Repository\MatiereRepository;
use App\Repository\ProfesseurRepository;
use Symfony\Component\HttpFoundation\Request;
use Doctrine\Common\Persistence\ObjectManager;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;



class AjoutController extends AbstractController
{
    
    /**
     * @Route("/lister_matiere", name="lister_mat")
     */
    public function index(Request $request,MatiereRepository $mat)
    {
        if ($request->isXmlHttpRequest()) {
            $list = $mat->listerMatiere() ;
            $data = $request->get('code') ;
            $tab_id = array() ;
            $tab_nom = array();
            foreach($list as $key=>$value) {
                array_push($tab_id,$value->getId()) ;
                array_push($tab_nom,$value->getNom()) ;
            }
            
            if($data!="") {
                return new JsonResponse(array('data_id' => json_encode($tab_id),'data_nom' => json_encode($tab_nom)));
            }
           
        }

        return $this->render('page/ajax.html.twig');
    }

    /**
     * @Route("/ajout_prof", name="ajout_prof")
     */
    public function ajout_prof(Request $request, MatiereRepository $mat,ProfesseurRepository $pr,ObjectManager $om)
    {
        if ($request->isXmlHttpRequest()) {
           $listeP = $pr->lister_prof() ;
            $data_nom = $request->get('nom');
            $data_mat = $request->get('mat');
            $p = new Professeur() ;
            $p->setNom($data_nom) ;
            $matiere = new Matiere() ;
            // ravao tsy mety ty de tonga de setNom() @ matiere iany zany
            $matiere->setNom($data_mat) ;
            $p->addMatiere($matiere) ;
            $om->persist($p) ;
            $om->flush() ;
            $tab_matiere = array();
            $tab_nom = array();
            // foreach ($listP as $key => $value) {
            //     array_push($tab_matiere, $value->getId());
            //     array_push($tab_nom, $value->getNom());
            // }

            // if ($data != "") {
            //     return new JsonResponse(array('data_id' => json_encode($tab_id), 'data_nom' => json_encode($tab_nom)));
            // }
            return new JsonResponse(array('data' => json_encode("ok")));
        }

        return $this->render('page/ajax.html.twig');
    }
}
