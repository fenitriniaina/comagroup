<?php

namespace App\Controller;

use App\Entity\Etudiant;
use App\Repository\MatiereRepository;
use App\Repository\EtudiantRepository;
use Symfony\Component\HttpFoundation\Request;
use Doctrine\Common\Persistence\ObjectManager;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class PageController extends AbstractController
{   
    /**
     * @Route("/" , name="accueil")
     */
    public function accueil(EtudiantRepository $er) {
        $et = $er->select_etudiant() ;
        return $this->render('page/accueil.html.twig',[
            'et'=>$et
        ]) ;
    }

    /**
     * @Route("/ajouter-prof-matiere" , name="ajouter_prof_matiere")
     */
    public function ajouter_prof_matiere(MatiereRepository $mr) {

        $liste = $mr->listerMatiere() ;
       
        return $this->render('page/ajax.html.twig',[
            "mat" => $liste 
        ]) ;
    }
    
}
