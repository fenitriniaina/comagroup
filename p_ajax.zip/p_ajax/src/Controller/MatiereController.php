<?php

namespace App\Controller;

use App\Repository\MatiereRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;

class MatiereController extends AbstractController
{
    /**
     * @Route("/listeMat", name="listeMat")
     */
    public function index(MatiereRepository $mr)
    {
        $liste = $mr->listerMatiere();
        return $this->render('matiere/index.html.twig', [
            'liste' => $liste,
        ]);
    }
}