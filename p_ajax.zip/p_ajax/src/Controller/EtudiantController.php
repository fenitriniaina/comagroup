<?php

namespace App\Controller;

use App\Entity\Classe;
use App\Entity\Matiere;
use App\Entity\Etudiant;
use App\Form\ClasseType;
use App\Entity\Professeur;
use App\Form\EtudiantType;

use App\Repository\ClasseRepository;
use App\Repository\MatiereRepository;
use Symfony\Component\BrowserKit\Response;
use Symfony\Component\HttpFoundation\Request;
use Doctrine\Common\Persistence\ObjectManager;
use Symfony\Component\HttpFoundation\File\File;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class EtudiantController extends AbstractController
{
    /**
     * @Route("/r_etudiant" , name="r_etudiant")
     */
    public function register_etudiant(Request $r, ObjectManager $m, ClasseRepository $cr)
    {
        $etudiant = new Etudiant();
        $form = $this->createForm(EtudiantType::class, $etudiant);
        // si le formulaire est soumis 
        $form->handleRequest($r);
        if ($form->isSubmitted() && $form->isValid()) {
            //dump($r) ;
            //$etudiant = $form->getData(); // zay de tafiditra ao le donnée rht hihihi     
            //dump($etudiant) ;
            $matricule = $form->get('matricule')->getData();
            $nom = $form->get('nom')->getData();
            $classe = $form->get('classe')->getData();
            // alaina le image 
            $file  = $form['image']->getData();
            dump($file);
            // nouveau nom du fichier 
            $fileName = md5(uniqid()) . "." . $file->guessExtension();
            $file->move($this->getParameter('upload_directory'), $fileName);
            //dump($matricule) ;
            $etudiant->setMatricule($matricule)
                ->setNom($nom)
                ->setClasse($classe)
                ->setImage($fileName);

            $m->persist($etudiant);
            $m->flush(); // de zay deviiiita :D 
            return $this->redirectToRoute('accueil');
        }
        $c = new Classe();
        // on crée notre fomrulaire ^
        $form_classe = $this->createForm(ClasseType::class, $c);
        $form_classe->handleRequest($r);
        if ($form_classe->isSubmitted() && $form_classe->isValid()) {
            $nom_classe = $form_classe->get('nom')->getData();
            $c->setNom($nom_classe);
            $une_classe = $cr->select_une_classe($c->getNom());
            $n = count($une_classe);
            if ($n == 0) {
                $m->persist($c);
                $m->flush();
            }
        }

        // selection de tous les classes

        $les_classes = $cr->select_classe();


        return $this->render('page/r_etudiant.html.twig', [
            'form' => $form->createView(),
            'form_classe' => $form_classe->createView(),
            'les_classes' => $les_classes
        ]);
    }

    /**
     * @Route("/ajax_prof" , name="link_ajax_prof")
     */

    function testAjax(Request $request)
    {
        if ($request->isXmlHttpRequest()) {
            $nom_prof = $request->get('nom_prof');
            $matiere_prof = $request->get('matiere_prof');
            $prof = new Professeur();
            $prof->setNom($nom_prof);
            $prof->addMatiere($matiere_prof);
            //$om->persist($matiere);
            //$om->flush();
            return new JsonResponse(array('data' => json_encode("ok")));
        }

        return $this->render('page/ajax.html.twig');
    }

    /**
     * @Route("/ajax_matiere" , name="link_ajax_matieres")
     */

    function testAjax_mat(Request $request, ObjectManager $om, MatiereRepository $mr)
    {
        if ($request->isXmlHttpRequest()) {
            $nom_mat = $request->get('nom_mat');
            $coef = $request->get('coef');
            $matiere = new Matiere();
            $matiere->setNom($nom_mat);
            $matiere->setCoef($coef);
            $om->persist($matiere);
            $om->flush();
            
            return new JsonResponse(array('data' => json_encode("ok")));
        }

        return $this->render('page/ajax.html.twig');
    }
}