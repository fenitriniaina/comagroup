<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* page/ajax.html.twig */
class __TwigTemplate_8d0e536bf2e86d4faf83366cbcd04b8a4e45382ee4fb8f311b0dcfbec9ad7124 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
            'javascripts' => [$this, 'block_javascripts'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "page/ajax.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "page/ajax.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "page/ajax.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 2
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "\t<div class=\"col-lg-4 col-md-4 \">
\t\t<h3>Ajout de matière</h3>
\t\t<form>
\t\t\t<div class=\"form-group\">
\t\t\t\t<label for=\"\">Nom de la matière :
\t\t\t\t</label>
\t\t\t\t<input type=\"text\" id=\"nom_mat\" class=\"form-control\">
\t\t\t</div>
\t\t\t<div class=\"form-group\">
\t\t\t\t<label for=\"\">Coeff :
\t\t\t\t</label>
\t\t\t\t<input type=\"number\" id=\"coef\" class=\"form-control\">
\t\t\t</div>
\t\t\t<div class=\"form-group\">
\t\t\t\t<input type=\"submit\" value=\"Ajouter\" id=\"ajout_matiere\" class=\"form-control btn btn-primary\">
\t\t\t</div>

\t\t</form>

\t</div>
\t<div class=\"col-lg-4 col-md-4\">

\t\t<h3>Ajout de prof</h3>
\t\t<form>
\t\t\t<div class=\"form-group\">
\t\t\t\t<label for=\"\">Nom du prof :
\t\t\t\t</label>
\t\t\t\t<input type=\"text\" id=\"nom_prof\" class=\"form-control\">
\t\t\t</div>
\t\t\t<div class=\"form-group\">
\t\t\t\t<label for=\"\">Matiere :
\t\t\t\t</label>
\t\t\t\t<select name=\"\" id=\"matiere_prof\" class=\"form-control\">
\t\t\t\t\t";
        // line 36
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["mat"]) || array_key_exists("mat", $context) ? $context["mat"] : (function () { throw new RuntimeError('Variable "mat" does not exist.', 36, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["l"]) {
            // line 37
            echo "\t\t\t\t\t\t<option data-id = ";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["l"], "id", [], "any", false, false, false, 37), "html", null, true);
            echo " value=\"";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["l"], "nom", [], "any", false, false, false, 37), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["l"], "nom", [], "any", false, false, false, 37), "html", null, true);
            echo "</option>
\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['l'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 39
        echo "\t\t\t\t</select>

\t\t\t</div>
\t\t\t<div class=\"form-group\">
\t\t\t\t<input type=\"submit\" value=\"Ajouter\" id=\"ajout_prof\" class=\"form-control btn btn-primary\">

\t\t\t</div>

\t\t\t
\t\t</form>

\t</div>


\t<div class=\"col-lg-4\"></div>
\t
\t


";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 59
    public function block_javascripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        // line 60
        echo "\t<script>
\t\t\$(document).ready(function(){
\t\t\t\t\$('#ajout_matiere').click(function(e) {
\t\t\t\te.preventDefault()
\t\t\t\tvar nom = \$('#nom_mat').val()
\t\t\t\tvar coef = \$('#coef').val()
\t\t\t\tvar data = {
\t\t\t\t\tnom_mat: nom,
\t\t\t\t\tcoef: coef
\t\t\t\t}
\t\t\t\t\$.ajax({
\t\t\t\t\ttype: 'POST',
\t\t\t\t\turl: '/ajax_matiere',
\t\t\t\t\tdata: data,
\t\t\t\t\tdataType: 'json',
\t\t\t\t\tsuccess: function(response) {
\t\t\t\t\t\tvar resultat = JSON.parse(response['data'])
\t\t\t\t\t\tif (resultat == 'ok') {
\t\t\t\t\t\t\t\$.ajax({
\t\t\t\t\t\t\t\ttype : \"POST\" ,
\t\t\t\t\t\t\t\turl : \"/lister_matiere\",
\t\t\t\t\t\t\t\tdata : {\"code\" : \"afficher\"} ,
\t\t\t\t\t\t\t\tsuccess : function(retour) {
\t\t\t\t\t\t\t\t\tvar resultat_id = JSON.parse(retour['data_id'])
\t\t\t\t\t\t\t\t\tvar resultat_nom = JSON.parse(retour['data_nom'])
\t\t\t\t\t\t\t\t\tvar a = '' ;
\t\t\t\t\t\t\t\t\t\$(\"#matiere_prof\").append(a);
\t\t\t\t\t\t\t\t\tvar i = resultat_id.length - 1 ;
\t\t\t\t\t\t\t\t\t\$(\"#matiere_prof\").append('<option data-id=\"'+resultat_id[i]+'\" value=\"'+resultat_nom[i]+'\">'+resultat_nom[i]+'</option>');


\t\t\t\t\t\t\t\t}

\t\t\t\t\t\t\t})
\t\t\t\t\t\t}
\t\t\t\t\t},
\t\t\t\t\terror: function() {
\t\t\t\t\t\talert('erreur')
\t\t\t\t\t}
\t\t\t\t})
\t\t\t})

\t\t\t// ajout prof

\t\t\t\$('#ajout_prof').click(function(e){
\t\t\t\te.preventDefault() ;
\t\t\t\tvar nom = \$('#nom_prof').val() ;
\t\t\t\tvar mat = \$('#matiere_prof').val() ;
\t\t\t\tconsole.log(nom+\" \"+mat) ;
\t\t\t\t\$.ajax({
\t\t\t\t\ttype : \"POST\" ,
\t\t\t\t\turl : \"/ajout_prof\",
\t\t\t\t\tdata : {\"nom\" : nom,\"mat\" : mat} ,
\t\t\t\t\tsuccess : function(retour) {
\t\t\t\t\t\t// var resultat_id = JSON.parse(retour['data_id'])
\t\t\t\t\t\t// var resultat_nom = JSON.parse(retour['data_nom'])
\t\t\t\t\t\t// var a = '' ;
\t\t\t\t\t\t// \$(\"#matiere_prof\").append(a);
\t\t\t\t\t\t// var i = resultat_id.length - 1 ;
\t\t\t\t\t\t// \$(\"#matiere_prof\").append('<option data-id=\"'+resultat_id[i]+'\">'+resultat_nom[i]+'</option>');
\t\t\t\t\t\tvar resultat = JSON.parse(retour['data']) ;
\t\t\t\t\t\tconsole.log(resultat) ;

\t\t\t\t\t}

\t\t\t\t})
\t\t\t})

\t\t})
\t</script>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "page/ajax.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  160 => 60,  150 => 59,  121 => 39,  108 => 37,  104 => 36,  69 => 3,  59 => 2,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"base.html.twig\" %}
{% block body %}
\t<div class=\"col-lg-4 col-md-4 \">
\t\t<h3>Ajout de matière</h3>
\t\t<form>
\t\t\t<div class=\"form-group\">
\t\t\t\t<label for=\"\">Nom de la matière :
\t\t\t\t</label>
\t\t\t\t<input type=\"text\" id=\"nom_mat\" class=\"form-control\">
\t\t\t</div>
\t\t\t<div class=\"form-group\">
\t\t\t\t<label for=\"\">Coeff :
\t\t\t\t</label>
\t\t\t\t<input type=\"number\" id=\"coef\" class=\"form-control\">
\t\t\t</div>
\t\t\t<div class=\"form-group\">
\t\t\t\t<input type=\"submit\" value=\"Ajouter\" id=\"ajout_matiere\" class=\"form-control btn btn-primary\">
\t\t\t</div>

\t\t</form>

\t</div>
\t<div class=\"col-lg-4 col-md-4\">

\t\t<h3>Ajout de prof</h3>
\t\t<form>
\t\t\t<div class=\"form-group\">
\t\t\t\t<label for=\"\">Nom du prof :
\t\t\t\t</label>
\t\t\t\t<input type=\"text\" id=\"nom_prof\" class=\"form-control\">
\t\t\t</div>
\t\t\t<div class=\"form-group\">
\t\t\t\t<label for=\"\">Matiere :
\t\t\t\t</label>
\t\t\t\t<select name=\"\" id=\"matiere_prof\" class=\"form-control\">
\t\t\t\t\t{% for l in mat %}
\t\t\t\t\t\t<option data-id = {{l.id}} value=\"{{l.nom}}\">{{l.nom}}</option>
\t\t\t\t\t{% endfor %}
\t\t\t\t</select>

\t\t\t</div>
\t\t\t<div class=\"form-group\">
\t\t\t\t<input type=\"submit\" value=\"Ajouter\" id=\"ajout_prof\" class=\"form-control btn btn-primary\">

\t\t\t</div>

\t\t\t
\t\t</form>

\t</div>


\t<div class=\"col-lg-4\"></div>
\t
\t


{% endblock %}
{% block javascripts %}
\t<script>
\t\t\$(document).ready(function(){
\t\t\t\t\$('#ajout_matiere').click(function(e) {
\t\t\t\te.preventDefault()
\t\t\t\tvar nom = \$('#nom_mat').val()
\t\t\t\tvar coef = \$('#coef').val()
\t\t\t\tvar data = {
\t\t\t\t\tnom_mat: nom,
\t\t\t\t\tcoef: coef
\t\t\t\t}
\t\t\t\t\$.ajax({
\t\t\t\t\ttype: 'POST',
\t\t\t\t\turl: '/ajax_matiere',
\t\t\t\t\tdata: data,
\t\t\t\t\tdataType: 'json',
\t\t\t\t\tsuccess: function(response) {
\t\t\t\t\t\tvar resultat = JSON.parse(response['data'])
\t\t\t\t\t\tif (resultat == 'ok') {
\t\t\t\t\t\t\t\$.ajax({
\t\t\t\t\t\t\t\ttype : \"POST\" ,
\t\t\t\t\t\t\t\turl : \"/lister_matiere\",
\t\t\t\t\t\t\t\tdata : {\"code\" : \"afficher\"} ,
\t\t\t\t\t\t\t\tsuccess : function(retour) {
\t\t\t\t\t\t\t\t\tvar resultat_id = JSON.parse(retour['data_id'])
\t\t\t\t\t\t\t\t\tvar resultat_nom = JSON.parse(retour['data_nom'])
\t\t\t\t\t\t\t\t\tvar a = '' ;
\t\t\t\t\t\t\t\t\t\$(\"#matiere_prof\").append(a);
\t\t\t\t\t\t\t\t\tvar i = resultat_id.length - 1 ;
\t\t\t\t\t\t\t\t\t\$(\"#matiere_prof\").append('<option data-id=\"'+resultat_id[i]+'\" value=\"'+resultat_nom[i]+'\">'+resultat_nom[i]+'</option>');


\t\t\t\t\t\t\t\t}

\t\t\t\t\t\t\t})
\t\t\t\t\t\t}
\t\t\t\t\t},
\t\t\t\t\terror: function() {
\t\t\t\t\t\talert('erreur')
\t\t\t\t\t}
\t\t\t\t})
\t\t\t})

\t\t\t// ajout prof

\t\t\t\$('#ajout_prof').click(function(e){
\t\t\t\te.preventDefault() ;
\t\t\t\tvar nom = \$('#nom_prof').val() ;
\t\t\t\tvar mat = \$('#matiere_prof').val() ;
\t\t\t\tconsole.log(nom+\" \"+mat) ;
\t\t\t\t\$.ajax({
\t\t\t\t\ttype : \"POST\" ,
\t\t\t\t\turl : \"/ajout_prof\",
\t\t\t\t\tdata : {\"nom\" : nom,\"mat\" : mat} ,
\t\t\t\t\tsuccess : function(retour) {
\t\t\t\t\t\t// var resultat_id = JSON.parse(retour['data_id'])
\t\t\t\t\t\t// var resultat_nom = JSON.parse(retour['data_nom'])
\t\t\t\t\t\t// var a = '' ;
\t\t\t\t\t\t// \$(\"#matiere_prof\").append(a);
\t\t\t\t\t\t// var i = resultat_id.length - 1 ;
\t\t\t\t\t\t// \$(\"#matiere_prof\").append('<option data-id=\"'+resultat_id[i]+'\">'+resultat_nom[i]+'</option>');
\t\t\t\t\t\tvar resultat = JSON.parse(retour['data']) ;
\t\t\t\t\t\tconsole.log(resultat) ;

\t\t\t\t\t}

\t\t\t\t})
\t\t\t})

\t\t})
\t</script>
{% endblock %}
", "page/ajax.html.twig", "F:\\Projet_symfony\\Admin\\templates\\page\\ajax.html.twig");
    }
}
