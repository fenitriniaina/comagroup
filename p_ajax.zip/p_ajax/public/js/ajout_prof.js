// $(document).ready(function() {
//     $('#ajout_prof').click(function(e) {
//         e.preventDefault()
//         var nom = $('#nom_prof').val()
//         var matiere = $('#matiere_prof').val()
//         var data = {
//             nom_prof: nom,
//             matiere_prof: matiere
//         }
//         $.ajax({
//             type: 'POST',
//             url: '/ajax_prof',
//             data: data,
//             dataType: 'json',
//             success: function(response) {
//                 var resultat = JSON.parse(response['data'])
//                 if (resultat == 'ok') {
//                     $('#matiere_prof').load('matiere/index.html.twig')
//                 }
//             },
//             error: function() {
//                 alert('erreur')
//             }
//         })
//     })

//     $('#ajout_matiere').click(function(e) {
//         e.preventDefault()
//         var nom = $('#nom_mat').val()
//         var coef = $('#coef').val()
//         var data = {
//             nom_mat: nom,
//             coef: coef
//         }
//         $.ajax({
//             type: 'POST',
//             url: '/ajax_matiere',
//             data: data,
//             dataType: 'json',
//             success: function(response) {
//                 var resultat = JSON.parse(response['data'])
//                 if (resultat == 'ok') {
//                     alert('viiitaaaaa')
//                 }
//             },
//             error: function() {
//                 alert('erreur')
//             }
//         })
//     })
// })